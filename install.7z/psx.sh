#!/bin/sh
wget -r -nd -A*.7z ftp://ftp.cluster023.hosting.ovh.net/snap-psx/