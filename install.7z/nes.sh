#!/bin/sh
wget -c -r -nd -A*.* ftp://ftp.cluster023.hosting.ovh.net/snap/snap-nes/